import json
import numpy as np
import xarray as xr
from config import BOUNDARY_OUTPUT, DEPTH_OUTPUT, DIRECTION_BINS, MAX_FREQUENCY_HZ, MIN_FREQUENCY_HZ, PROJECT_NAME, PROJECT_NUMBER, PROCESSED_DIR, SWAN_INPUT_OUTPUT, WIND_FILE, WIND_OUTPUT, ensure_directories
from generate_boundary import generate_boundary
from generate_depth import generate_depth
from generate_wind import generate_wind

def _find_name(dataset, candidates):
    for n in candidates:
        if n in dataset.coords or n in dataset.dims: return n
    raise KeyError(f"Nenhum nome encontrado entre: {candidates}")

def _time(v):
    d,c=np.datetime_as_string(v,unit='s').split('T'); return f"{d.replace('-','')}.{c.replace(':','')}"

def _dt_hours(times):
    sec=np.diff(times.astype('datetime64[s]').astype(np.int64))
    if len(sec)==0 or np.any(sec<=0) or not np.all(sec==sec[0]): raise ValueError('Horários inválidos ou irregulares.')
    return sec[0]/3600.0

def fmt(v): return f"{v:.10g}"

def generate_input() -> None:
    ensure_directories(); grid_file=PROCESSED_DIR/'grid.json'
    g=generate_depth() if (not grid_file.exists() or not DEPTH_OUTPUT.exists()) else json.loads(grid_file.read_text(encoding='utf-8'))
    if not WIND_OUTPUT.exists(): generate_wind()
    if not BOUNDARY_OUTPUT.exists(): generate_boundary()
    with xr.open_dataset(WIND_FILE) as ds:
        tn=_find_name(ds,("valid_time","time","forecast_time","datetime")); times=np.sort(np.asarray(ds[tn].values))
    start=_time(times[0]); end=_time(times[-1]); dt=fmt(_dt_hours(times))
    content=f"""PROJECT '{PROJECT_NAME}' '{PROJECT_NUMBER}'

SET LEVEL 0.0 MAXERR=99 NAUTICAL
COORDINATES SPHERICAL CCM
MODE NONSTATIONARY

CGRID REGULAR {fmt(g['x0'])} {fmt(g['y0'])} 0.0 {fmt(g['x_length'])} {fmt(g['y_length'])} {g['mx']} {g['my']} CIRCLE {DIRECTION_BINS} {MIN_FREQUENCY_HZ} {MAX_FREQUENCY_HZ}

INPGRID BOTTOM REGULAR {fmt(g['x0'])} {fmt(g['y0'])} 0.0 {g['mx']} {g['my']} {fmt(g['dx'])} {fmt(g['dy'])}
READINP BOTTOM 1.0 'depth.bot' 3 0 FREE

INPGRID WIND REGULAR {fmt(g['x0'])} {fmt(g['y0'])} 0.0 {g['mx']} {g['my']} {fmt(g['dx'])} {fmt(g['dy'])} NONSTATIONARY {start} {dt} HR {end}
READINP WIND 1.0 'wind.txt' 3 0 FREE

BOUND SHAPESPEC JONSWAP 3.3 MEAN DSPR DEGREES
BOUNDSPEC SIDE NORTH CCW VARIABLE FILE 'boundary.txt'
BOUNDSPEC SIDE EAST CCW VARIABLE FILE 'boundary.txt'
BOUNDSPEC SIDE SOUTH CCW VARIABLE FILE 'boundary.txt'
BOUNDSPEC SIDE WEST CCW VARIABLE FILE 'boundary.txt'

BLOCK 'COMPGRID' NOHEAD 'output.mat' LAY 3 HSIGN TM01 TPS DIR WIND OUTPUT {start} {dt} HR

COMPUTE NONSTATIONARY {start} {dt} HR {end}
STOP
"""
    SWAN_INPUT_OUTPUT.write_text(content,encoding='ascii')
    print(f"INPUT gerado: {SWAN_INPUT_OUTPUT}")

if __name__=='__main__':
    generate_input()
