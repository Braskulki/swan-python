from pathlib import Path
import os

ROOT_DIR = Path(__file__).resolve().parent
RAW_DIR = ROOT_DIR / "data" / "raw"
PROCESSED_DIR = ROOT_DIR / "data" / "processed"
GEBCO_FILE = RAW_DIR / "gebco.nc"
WIND_FILE = RAW_DIR / "wind.nc"
WAVES_FILE = RAW_DIR / "waves.nc"
DEPTH_OUTPUT = PROCESSED_DIR / "depth.bot"
WIND_OUTPUT = PROCESSED_DIR / "wind.txt"
BOUNDARY_OUTPUT = PROCESSED_DIR / "boundary.txt"
SWAN_INPUT_OUTPUT = PROCESSED_DIR / "INPUT"
LON_MIN = -48.0
LON_MAX = -44.0
LAT_MIN = -25.0
LAT_MAX = -22.0
GEBCO_STEP = 9
DIRECTION_BINS = 36
MIN_FREQUENCY_HZ = 0.04
MAX_FREQUENCY_HZ = 1.0
SWAN_DOCKER_IMAGE = os.getenv("SWAN_DOCKER_IMAGE", "swan:latest")
SWAN_EXECUTABLE = os.getenv("SWAN_EXECUTABLE", "swan")
DOCKER_PLATFORM = os.getenv("SWAN_DOCKER_PLATFORM", "")
PROJECT_NAME = "TEST"
PROJECT_NUMBER = "01"

def ensure_directories() -> None:
    RAW_DIR.mkdir(parents=True, exist_ok=True)
    PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
