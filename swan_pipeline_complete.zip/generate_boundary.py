import json
import numpy as np
import xarray as xr
from config import BOUNDARY_OUTPUT, PROCESSED_DIR, WAVES_FILE, ensure_directories
from generate_depth import generate_depth

def _find_name(dataset: xr.Dataset, candidates: tuple[str, ...]) -> str:
    for name in candidates:
        if name in dataset.variables or name in dataset.coords or name in dataset.dims:
            return name
    raise KeyError(f"Nenhum nome encontrado entre: {candidates}")

def _load_grid() -> dict:
    p=PROCESSED_DIR/'grid.json'; return generate_depth() if not p.exists() else json.loads(p.read_text(encoding='utf-8'))

def _circ(values):
    r=np.deg2rad(values); return float(np.rad2deg(np.arctan2(np.nanmean(np.sin(r)),np.nanmean(np.cos(r))))%360)

def _time(v):
    d,c=np.datetime_as_string(v,unit='s').split('T'); return f"{d.replace('-','')}.{c.replace(':','')}"

def generate_boundary() -> None:
    ensure_directories()
    if not WAVES_FILE.exists(): raise FileNotFoundError(f"Arquivo ERA5 de ondas não encontrado: {WAVES_FILE}")
    g=_load_grid(); lon=np.asarray(g['lon']); lat=np.asarray(g['lat'])
    with xr.open_dataset(WAVES_FILE) as ds:
        lon_n=_find_name(ds,("longitude","lon")); lat_n=_find_name(ds,("latitude","lat")); time_n=_find_name(ds,("valid_time","time","forecast_time","datetime")); hs_n=_find_name(ds,("swh",)); dir_n=_find_name(ds,("mwd",)); per_n=_find_name(ds,("mwp","mwdp"))
        ds=ds.sortby(lon_n).sortby(lat_n).sortby(time_n)
        def interp(name):
            return ds[name].squeeze(drop=True).interp({lon_n:xr.DataArray(lon,dims=(lon_n,)),lat_n:xr.DataArray(lat,dims=(lat_n,))}).transpose(time_n,lat_n,lon_n)
        hs=np.asarray(interp(hs_n).values,float); dr=np.asarray(interp(dir_n).values,float); pe=np.asarray(interp(per_n).values,float); times=np.asarray(ds[time_n].values)
    if not np.isfinite(hs).all() or not np.isfinite(dr).all() or not np.isfinite(pe).all(): raise ValueError('A interpolação das ondas produziu NaN.')
    lines=['TPAR']
    for i,t in enumerate(times):
        def perimeter(a): return np.concatenate((a[0,:],a[-1,:],a[1:-1,0],a[1:-1,-1]))
        h=max(float(np.mean(perimeter(hs[i]))),0.01); p=max(float(np.mean(perimeter(pe[i]))),0.1); d=_circ(perimeter(dr[i]))
        lines.append(f"{_time(t)} {h:.4f} {p:.4f} {d:.2f} 30.00")
    BOUNDARY_OUTPUT.write_text('
'.join(lines)+'
',encoding='ascii')
    print(f"Condição TPAR gerada: {BOUNDARY_OUTPUT}")

if __name__=='__main__':
    generate_boundary()
